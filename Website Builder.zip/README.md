
  # Website Builder

  This is a code bundle for Website Builder. The original project is available at https://www.figma.com/design/AeVz4y20nVORNsGEDWfALK/Website-Builder.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  