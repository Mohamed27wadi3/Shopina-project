import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Users,
  BarChart3,
  Settings,
  Store,
  CreditCard,
  HelpCircle,
} from "lucide-react";

const menuItems = [
  { icon: LayoutDashboard, label: "Tableau de bord", path: "/dashboard" },
  { icon: ShoppingCart, label: "Commandes", path: "/dashboard" },
  { icon: Package, label: "Produits", path: "/dashboard" },
  { icon: Users, label: "Clients", path: "/dashboard" },
  { icon: BarChart3, label: "Statistiques", path: "/dashboard" },
  { icon: Store, label: "Ma boutique", path: "/shop" },
  { icon: CreditCard, label: "Paiements", path: "/pricing" },
  { icon: Settings, label: "Paramètres", path: "/profile" },
  { icon: HelpCircle, label: "Aide", path: "/support" },
];

export function DashboardSidebar() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <aside className="w-64 bg-white border-r border-gray-200 min-h-screen p-6 hidden lg:block">
      <nav className="space-y-2">
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={index}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                isActive
                  ? "bg-gradient-to-r from-[#0077FF] to-[#5AC8FA] text-white shadow-lg shadow-[#0077FF]/20"
                  : "text-[#0A1A2F]/70 hover:bg-gray-50 hover:text-[#0077FF]"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span style={{ fontWeight: isActive ? '600' : '500' }}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>

      {/* Upgrade Card */}
      <div className="mt-8 p-4 bg-gradient-to-br from-[#0077FF]/5 to-[#5AC8FA]/5 rounded-2xl border border-[#0077FF]/20">
        <p className="text-[#0A1A2F] mb-2" style={{ fontWeight: '700' }}>
          Passez au plan Pro
        </p>
        <p className="text-[#0A1A2F]/60 text-sm mb-4">
          Débloquez toutes les fonctionnalités premium
        </p>
        <button 
          onClick={() => navigate("/pricing")}
          className="w-full bg-[#FFD43B] hover:bg-[#FFD43B]/90 text-[#0A1A2F] py-2 rounded-xl transition-colors" 
          style={{ fontWeight: '600' }}
        >
          Mettre à niveau
        </button>
      </div>
    </aside>
  );
}