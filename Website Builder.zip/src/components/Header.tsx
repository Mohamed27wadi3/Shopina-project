import { ShoppingBag } from "lucide-react";
import { Button } from "./ui/button";
import { Link, useNavigate } from "react-router-dom";

export function Header() {
  const navigate = useNavigate();

  return (
    <header className="border-b border-gray-100 bg-white sticky top-0 z-50">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#0077FF] to-[#5AC8FA] flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 text-white" />
            </div>
            <span className="text-[#0A1A2F] tracking-tight" style={{ fontSize: '24px', fontWeight: '700' }}>
              Shopina
            </span>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link to="/#features" className="text-[#0A1A2F] hover:text-[#0077FF] transition-colors">
              Fonctionnalités
            </Link>
            <Link to="/pricing" className="text-[#0A1A2F] hover:text-[#0077FF] transition-colors">
              Tarifs
            </Link>
            <Link to="/templates" className="text-[#0A1A2F] hover:text-[#0077FF] transition-colors">
              Templates
            </Link>
            <Link to="/shop" className="text-[#0A1A2F] hover:text-[#0077FF] transition-colors">
              Boutique
            </Link>
            <Link to="/support" className="text-[#0A1A2F] hover:text-[#0077FF] transition-colors">
              Support
            </Link>
          </nav>

          {/* CTA Buttons */}
          <div className="flex items-center gap-3">
            <Button 
              onClick={() => navigate("/login")}
              variant="ghost" 
              className="text-[#0A1A2F] hover:text-[#0077FF] hover:bg-[#0077FF]/5"
            >
              Se connecter
            </Button>
            <Button 
              onClick={() => navigate("/signup")}
              className="bg-[#0077FF] hover:bg-[#0077FF]/90 text-white rounded-xl px-6 shadow-lg shadow-[#0077FF]/20"
            >
              Créer ma boutique
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}